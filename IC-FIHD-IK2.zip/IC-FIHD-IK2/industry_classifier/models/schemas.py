"""Pydantic 数据模型，用于 API 请求/响应的结构化定义"""
from typing import Optional
from pydantic import BaseModel, Field


# ==================== 知识库上传接口模型 ====================

class KBUploadTextRequest(BaseModel):
    """直接上传文本到知识库"""
    kb_name: str = Field(..., description="知识库名称：kb_a / kb_b / kb_c")
    content: str = Field(..., description="文档文本内容")
    doc_title: Optional[str] = Field(None, description="文档标题（可选，用于元数据）")


class KBUploadKeywordRequest(BaseModel):
    """批量上传关键词映射到知识库C"""
    # 每条记录格式：主营业务关键词：XXX|所属行业：XXX|行业代码：XXX
    records: list[str] = Field(..., description="关键词映射记录列表")


class KBUploadResponse(BaseModel):
    success: bool
    kb_name: str
    indexed_docs: int
    indexed_chunks: int
    message: str


# ==================== 工作流接口模型 ====================

class ClassifyRequest(BaseModel):
    """行业分类工作流输入"""
    company_name: str = Field(..., description="公司名称")
    business_name: str = Field(..., description="要识别行业的业务名称")
    all_business_name: str = Field(..., description="公司全部业务名称列表")
    company_info: str = Field(..., description="公司整体业务信息")
    business_info: str = Field(..., description="要识别行业的业务详细信息")
    dm_industry_name: Optional[str] = Field("", description="DM预判行业名称（可选参考）")
    dm_industry_info: Optional[str] = Field("", description="DM预判行业信息（可选参考）")


class ClassifyResult(BaseModel):
    """行业分类工作流输出"""
    主体名称: str
    要识别行业的业务: str
    三级行业: str
    三级行业代码: str
    # 0 = 关键词匹配路径（快速），1 = 大模型判断路径
    LLM_REC_FLAG: str = "1"


class ClassifyResponse(BaseModel):
    success: bool
    path_type: str = Field(..., description="执行路径：keyword（关键词匹配）/ llm（大模型判断）")
    result: Optional[ClassifyResult] = None
    raw_output: str = Field("", description="工作流原始输出文本")
    error: Optional[str] = None
