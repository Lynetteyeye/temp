"""
应用配置模块
标注"伪代码"的配置项需替换为真实值，支持从 .env 文件加载
"""
from typing import Optional
from pydantic_settings import BaseSettings


class Settings(BaseSettings):

    # ==================== 大模型配置（伪代码，替换为真实值）====================
    # OpenAI 兼容接口地址，如 http://192.168.1.1:8000/v1
    LLM_BASE_URL: str = "YOUR_LLM_BASE_URL"
    LLM_API_KEY: str = "YOUR_LLM_API_KEY"
    LLM_MODEL: str = "qwen3-32b"
    LLM_TEMPERATURE: float = 0.3

    # ==================== Embedding 模型配置（伪代码）====================
    EMBEDDING_BASE_URL: str = "YOUR_EMBEDDING_BASE_URL"
    EMBEDDING_API_KEY: str = "YOUR_EMBEDDING_API_KEY"
    EMBEDDING_MODEL: str = "Qwen3-Embedding-8B"
    # Qwen3-Embedding-8B 的向量维度（部署时以实际输出为准）
    EMBEDDING_DIMENSION: int = 4096

    # ==================== Reranker 配置（伪代码）====================
    RERANKER_BASE_URL: str = "YOUR_RERANKER_BASE_URL"
    RERANKER_API_KEY: str = "YOUR_RERANKER_API_KEY"
    # 知识库A 使用 Qwen3-Reranker-8B，知识库B 使用 bge-reranker-large
    RERANKER_MODEL_A: str = "Qwen3-Reranker-8B"
    RERANKER_MODEL_B: str = "bge-reranker-large"

    # ==================== Elasticsearch 配置（伪代码）====================
    ES_HOST: str = "YOUR_ES_HOST"          # 如 http://192.168.1.1:9200
    ES_USERNAME: str = "YOUR_ES_USERNAME"
    ES_PASSWORD: str = "YOUR_ES_PASSWORD"
    ES_CA_CERTS: Optional[str] = None      # SSL 证书路径（HTTPS时使用）

    # ==================== ES 索引名称 ====================
    INDEX_KB_A: str = "industry_kb_a"      # 知识库A：行业分类标准
    INDEX_KB_B: str = "industry_kb_b"      # 知识库B：相似公司历史分类结果
    INDEX_KB_C: str = "industry_kb_c"      # 知识库C：关键词精确映射表

    # ==================== 父子分段配置 ====================
    PARENT_CHUNK_SIZE: int = 800           # 父级分段大小（字符数），用于向LLM提供完整上下文
    PARENT_CHUNK_OVERLAP: int = 100        # 父级分段重叠
    CHILD_CHUNK_SIZE: int = 200            # 子级分段大小，用于向量检索（更精准匹配）
    CHILD_CHUNK_OVERLAP: int = 50          # 子级分段重叠

    # ==================== 检索参数配置 ====================
    KB_A_TOP_K: int = 8                    # 知识库A Rerank 后最终返回数量
    KB_B_TOP_K: int = 6                    # 知识库B Rerank 后最终返回数量
    KB_C_TOP_K: int = 10                   # 知识库C 关键词检索返回数量
    KB_SUPPLEMENT_TOP_K: int = 1           # 补充检索（迭代）每次返回数量
    # 混合检索向量/BM25 权重（各占 50%，与 Dify 配置一致）
    HYBRID_VECTOR_WEIGHT: float = 0.5
    HYBRID_BM25_WEIGHT: float = 0.5
    KNN_NUM_CANDIDATES: int = 100          # KNN 候选集大小

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()
