"""
知识库文档上传模块
实现父子分段策略：
  - 父级分段（800字符）：上传到 parent 索引，供 LLM 读取完整上下文
  - 子级分段（200字符）：向量化后上传到 child 索引，用于精准检索
"""
import uuid
import asyncio
from typing import Optional
from langchain.text_splitter import RecursiveCharacterTextSplitter

from config import settings
from knowledge_base.es_client import (
    ensure_kb_indices,
    index_parent_doc,
    index_child_doc,
    index_kbc_doc,
)
from knowledge_base.retriever import embed_texts


# 父级分割器：大块，保留完整语义，用于最终提供给 LLM 的上下文
_parent_splitter = RecursiveCharacterTextSplitter(
    chunk_size=settings.PARENT_CHUNK_SIZE,
    chunk_overlap=settings.PARENT_CHUNK_OVERLAP,
    separators=["\n\n", "\n", "。", "；", " ", ""],
)

# 子级分割器：小块，提升向量检索的精准度
_child_splitter = RecursiveCharacterTextSplitter(
    chunk_size=settings.CHILD_CHUNK_SIZE,
    chunk_overlap=settings.CHILD_CHUNK_OVERLAP,
    separators=["\n\n", "\n", "。", "；", " ", ""],
)


async def upload_documents(
    kb_name: str,
    documents: list[str],
    metadata_list: Optional[list[dict]] = None,
) -> dict:
    """
    将文档列表上传到指定知识库（父子分段）

    流程：
      1. 将每个文档分割为父级分段
      2. 将每个父级分段再分割为子级分段
      3. 批量向量化所有子级分段
      4. 写入 ES（父文档 + 子文档）

    :param kb_name:        目标索引名（settings.INDEX_KB_A 或 INDEX_KB_B）
    :param documents:      原始文档文本列表
    :param metadata_list:  与 documents 对应的元数据列表（可选）
    :return:               统计信息字典
    """
    await ensure_kb_indices(kb_name)

    metadata_list = metadata_list or [{} for _ in documents]
    total_parents = 0
    total_children = 0

    # 收集所有子分块及其对应的 parent_id，批量向量化以减少 API 调用次数
    all_child_texts: list[str] = []
    all_child_meta: list[tuple[str, str, dict]] = []  # (chunk_id, parent_id, meta)

    for raw_doc, meta in zip(documents, metadata_list):
        # Step 1：父级分割
        parent_chunks = _parent_splitter.split_text(raw_doc)

        for p_chunk in parent_chunks:
            parent_id = str(uuid.uuid4())
            await index_parent_doc(kb_name, parent_id, p_chunk, meta)
            total_parents += 1

            # Step 2：子级分割
            child_chunks = _child_splitter.split_text(p_chunk)
            for c_chunk in child_chunks:
                chunk_id = str(uuid.uuid4())
                all_child_texts.append(c_chunk)
                all_child_meta.append((chunk_id, parent_id, meta))

    # Step 3：批量向量化（每批 32 条，避免超出模型输入限制）
    batch_size = 32
    for i in range(0, len(all_child_texts), batch_size):
        batch_texts = all_child_texts[i: i + batch_size]
        batch_meta  = all_child_meta[i: i + batch_size]
        embeddings  = await embed_texts(batch_texts)

        # Step 4：写入子文档
        tasks = [
            index_child_doc(kb_name, chunk_id, parent_id, text, emb, m)
            for (chunk_id, parent_id, m), text, emb
            in zip(batch_meta, batch_texts, embeddings)
        ]
        await asyncio.gather(*tasks)
        total_children += len(batch_texts)

    return {
        "kb_name":        kb_name,
        "indexed_docs":   len(documents),
        "indexed_parents": total_parents,
        "indexed_chunks": total_children,
    }


async def upload_keyword_records(records: list[str]) -> dict:
    """
    批量上传关键词映射记录到知识库C

    记录格式（固定）：
        主营业务关键词：XXX|所属行业：XXX|行业代码：XXX

    :param records: 关键词映射字符串列表
    :return:        统计信息字典
    """
    await ensure_kb_indices(settings.INDEX_KB_C)

    tasks = [
        index_kbc_doc(doc_id=str(uuid.uuid4()), content=record)
        for record in records
        if record.strip()
    ]
    await asyncio.gather(*tasks)

    return {
        "kb_name":       settings.INDEX_KB_C,
        "indexed_docs":  len(tasks),
        "indexed_chunks": len(tasks),
    }
