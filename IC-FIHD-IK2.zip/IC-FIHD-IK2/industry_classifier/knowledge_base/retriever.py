"""
知识库召回模块（父子分段召回 + Reranker）

召回流程：
  1. 将查询文本向量化（Embedding API）
  2. 对子文档索引执行混合检索（KNN + BM25），获取 fetch_k 条子文档
  3. 从子文档中提取 parent_id，批量获取父文档（去重）
  4. 调用 Reranker API 对父文档重排序（可选）
  5. 返回 top_k 条父文档内容

设计原因：
  - 子文档（小块）向量更精准，能定位到最相关的局部内容
  - 返回父文档（大块）保证 LLM 获得足够的上下文窗口
"""
import httpx
from typing import Optional
from langchain_openai import OpenAIEmbeddings

from config import settings
from knowledge_base.es_client import (
    hybrid_search_children,
    fetch_parent_docs,
    keyword_prefix_search,
)


# ==================== Embedding 客户端（伪代码：替换为真实地址）====================
_embeddings = OpenAIEmbeddings(
    base_url=settings.EMBEDDING_BASE_URL,   # 伪代码
    api_key=settings.EMBEDDING_API_KEY,     # 伪代码
    model=settings.EMBEDDING_MODEL,
)


async def embed_texts(texts: list[str]) -> list[list[float]]:
    """批量向量化文本（复用同一 Embedding 客户端）"""
    return await _embeddings.aembed_documents(texts)


async def embed_query(text: str) -> list[float]:
    """向量化单条查询文本"""
    return await _embeddings.aembed_query(text)


# ==================== Reranker 调用（伪代码：替换为真实地址）====================

async def rerank_documents(
    query: str,
    documents: list[str],
    model: str,
    top_n: int,
) -> list[int]:
    """
    调用 Reranker API 对文档列表重排序，返回排序后的原始索引列表

    接口格式（OpenAI 兼容 Reranker）：
        POST {RERANKER_BASE_URL}/v1/rerank
        {
          "model": "...",
          "query": "...",
          "documents": [...],
          "top_n": n
        }

    :param query:     查询文本
    :param documents: 待排序文档文本列表
    :param model:     Reranker 模型名（伪代码：替换为真实模型）
    :param top_n:     返回前 n 名
    :return:          按相关度降序排列的原始索引列表
    """
    if not documents:
        return []

    url = f"{settings.RERANKER_BASE_URL}/v1/rerank"   # 伪代码：替换为真实地址
    headers = {
        "Authorization": f"Bearer {settings.RERANKER_API_KEY}",  # 伪代码
        "Content-Type": "application/json",
    }
    payload = {
        "model":     model,
        "query":     query,
        "documents": documents,
        "top_n":     min(top_n, len(documents)),
    }

    async with httpx.AsyncClient(timeout=60.0) as client:
        resp = await client.post(url, json=payload, headers=headers)
        resp.raise_for_status()
        data = resp.json()

    # 标准响应格式：{"results": [{"index": i, "relevance_score": s}, ...]}
    ranked = sorted(data["results"], key=lambda x: x["relevance_score"], reverse=True)
    return [item["index"] for item in ranked]


# ==================== 父子分段召回主入口 ====================

async def retrieve_with_parent_child(
    kb_name: str,
    query: str,
    top_k: int,
    reranker_model: Optional[str] = None,
) -> list[dict]:
    """
    父子分段召回：检索子文档 → 获取父文档 → 可选 Rerank

    :param kb_name:        知识库索引名
    :param query:          查询文本
    :param top_k:          最终返回父文档数量
    :param reranker_model: Reranker 模型名，None 则跳过重排序
    :return:               父文档字典列表，每项包含 content、metadata
    """
    # 子文档召回量 = top_k * 4，确保父文档去重后仍有足够候选
    fetch_k = top_k * 4

    # Step 1：向量化查询
    query_vec = await embed_query(query)

    # Step 2：混合检索子文档（KNN + BM25）
    child_hits = await hybrid_search_children(kb_name, query, query_vec, fetch_k)
    if not child_hits:
        return []

    # Step 3：提取 parent_id（保序去重，最多取 top_k * 2 个父文档候选）
    seen: set[str] = set()
    parent_ids: list[str] = []
    for hit in child_hits:
        pid = hit.get("parent_id", "")
        if pid and pid not in seen:
            seen.add(pid)
            parent_ids.append(pid)
        if len(parent_ids) >= top_k * 2:
            break

    # Step 4：批量获取父文档
    parent_docs = await fetch_parent_docs(kb_name, parent_ids)
    if not parent_docs:
        return []

    # Step 5：Reranker 重排序（可选）
    if reranker_model and len(parent_docs) > 1:
        contents = [doc["content"] for doc in parent_docs]
        ranked_indices = await rerank_documents(query, contents, reranker_model, top_k)
        parent_docs = [parent_docs[i] for i in ranked_indices]

    return parent_docs[:top_k]


async def retrieve_kb_a(query: str, top_k: int) -> list[dict]:
    """召回知识库A（行业分类标准），使用 Qwen3-Reranker-8B"""
    return await retrieve_with_parent_child(
        kb_name=settings.INDEX_KB_A,
        query=query,
        top_k=top_k,
        reranker_model=settings.RERANKER_MODEL_A,
    )


async def retrieve_kb_b(query: str, top_k: int) -> list[dict]:
    """召回知识库B（相似公司历史结果），使用 bge-reranker-large"""
    return await retrieve_with_parent_child(
        kb_name=settings.INDEX_KB_B,
        query=query,
        top_k=top_k,
        reranker_model=settings.RERANKER_MODEL_B,
    )


async def retrieve_kb_a_supplement(query: str) -> list[dict]:
    """
    补充检索知识库A（用于迭代补充 B 中有 A 中没有的行业）
    top_k=1，不使用 Reranker（与原 Dify 配置一致）
    """
    return await retrieve_with_parent_child(
        kb_name=settings.INDEX_KB_A,
        query=query,
        top_k=settings.KB_SUPPLEMENT_TOP_K,
        reranker_model=None,
    )


async def retrieve_kb_c(keyword: str) -> list[dict]:
    """
    检索知识库C（关键词映射表）
    使用文本匹配，精确匹配在代码层完成
    """
    return await keyword_prefix_search(keyword, settings.KB_C_TOP_K)
