"""
Elasticsearch 客户端封装
负责连接管理、索引创建（父子两套索引）以及底层的读写操作
"""
from typing import Optional
from elasticsearch import AsyncElasticsearch
from config import settings


def get_es_client() -> AsyncElasticsearch:
    """构建异步 ES 客户端（伪代码：替换为真实连接参数）"""
    kwargs = {
        "hosts": [settings.ES_HOST],
        "basic_auth": (settings.ES_USERNAME, settings.ES_PASSWORD),
        "verify_certs": False,  # 生产环境建议开启并配置 CA 证书
    }
    if settings.ES_CA_CERTS:
        kwargs["ca_certs"] = settings.ES_CA_CERTS
        kwargs["verify_certs"] = True
    return AsyncElasticsearch(**kwargs)


# 全局单例客户端
es_client = get_es_client()


def _parent_index(kb_name: str) -> str:
    """父文档索引名：{kb_name}_parent"""
    return f"{kb_name}_parent"


def _child_index(kb_name: str) -> str:
    """子文档索引名：{kb_name}_child（存储向量，用于检索）"""
    return f"{kb_name}_child"


# ==================== 索引 Mapping 定义 ====================

def _parent_mapping() -> dict:
    """父文档索引 Mapping：存储原始完整内容，不需要向量字段"""
    return {
        "mappings": {
            "properties": {
                "doc_id":   {"type": "keyword"},
                "content":  {"type": "text", "analyzer": "standard"},
                "metadata": {"type": "object", "enabled": True},
                "kb_name":  {"type": "keyword"},
            }
        },
        "settings": {"number_of_shards": 1, "number_of_replicas": 0},
    }


def _child_mapping() -> dict:
    """子文档索引 Mapping：存储小分块 + 向量，用于 KNN 检索"""
    return {
        "mappings": {
            "properties": {
                "chunk_id":  {"type": "keyword"},
                "parent_id": {"type": "keyword"},   # 指向父文档 doc_id
                "content":   {"type": "text", "analyzer": "standard"},
                "embedding": {
                    "type":       "dense_vector",
                    "dims":       settings.EMBEDDING_DIMENSION,
                    "index":      True,
                    "similarity": "cosine",
                },
                "metadata":  {"type": "object", "enabled": True},
                "kb_name":   {"type": "keyword"},
            }
        },
        "settings": {"number_of_shards": 1, "number_of_replicas": 0},
    }


def _kbc_mapping() -> dict:
    """知识库C 索引 Mapping：纯文本关键词映射，无需向量"""
    return {
        "mappings": {
            "properties": {
                "doc_id":  {"type": "keyword"},
                # content 格式：主营业务关键词：XXX|所属行业：XXX|行业代码：XXX
                "content": {"type": "keyword"},    # keyword 类型支持精确匹配
                "kb_name": {"type": "keyword"},
            }
        },
        "settings": {"number_of_shards": 1, "number_of_replicas": 0},
    }


# ==================== 索引管理 ====================

async def ensure_kb_indices(kb_name: str) -> None:
    """确保父/子索引存在，不存在则创建（知识库C 单独处理）"""
    if kb_name == settings.INDEX_KB_C:
        idx = kb_name
        if not await es_client.indices.exists(index=idx):
            await es_client.indices.create(index=idx, body=_kbc_mapping())
        return

    for idx, mapping in [
        (_parent_index(kb_name), _parent_mapping()),
        (_child_index(kb_name),  _child_mapping()),
    ]:
        if not await es_client.indices.exists(index=idx):
            await es_client.indices.create(index=idx, body=mapping)


async def delete_kb_indices(kb_name: str) -> None:
    """删除知识库索引（慎用）"""
    if kb_name == settings.INDEX_KB_C:
        await es_client.indices.delete(index=kb_name, ignore_unavailable=True)
        return
    await es_client.indices.delete(index=_parent_index(kb_name), ignore_unavailable=True)
    await es_client.indices.delete(index=_child_index(kb_name),  ignore_unavailable=True)


# ==================== 父子文档写入 ====================

async def index_parent_doc(
    kb_name: str,
    doc_id: str,
    content: str,
    metadata: Optional[dict] = None,
) -> None:
    """写入父文档"""
    await es_client.index(
        index=_parent_index(kb_name),
        id=doc_id,
        document={
            "doc_id":   doc_id,
            "content":  content,
            "metadata": metadata or {},
            "kb_name":  kb_name,
        },
    )


async def index_child_doc(
    kb_name: str,
    chunk_id: str,
    parent_id: str,
    content: str,
    embedding: list[float],
    metadata: Optional[dict] = None,
) -> None:
    """写入子文档（含向量）"""
    await es_client.index(
        index=_child_index(kb_name),
        id=chunk_id,
        document={
            "chunk_id":  chunk_id,
            "parent_id": parent_id,
            "content":   content,
            "embedding": embedding,
            "metadata":  metadata or {},
            "kb_name":   kb_name,
        },
    )


async def index_kbc_doc(doc_id: str, content: str) -> None:
    """写入知识库C 关键词映射记录"""
    await es_client.index(
        index=settings.INDEX_KB_C,
        id=doc_id,
        document={"doc_id": doc_id, "content": content, "kb_name": settings.INDEX_KB_C},
    )


# ==================== 检索操作 ====================

async def hybrid_search_children(
    kb_name: str,
    query_text: str,
    query_embedding: list[float],
    fetch_k: int,
) -> list[dict]:
    """
    对子文档索引执行混合检索（KNN + BM25）
    fetch_k 通常设为 top_k 的 3~5 倍，以保证父文档去重后仍有足够数量
    """
    body = {
        "knn": {
            "field":          "embedding",
            "query_vector":   query_embedding,
            "k":              fetch_k,
            "num_candidates": settings.KNN_NUM_CANDIDATES,
            "boost":          settings.HYBRID_VECTOR_WEIGHT,
        },
        "query": {
            "match": {
                "content": {
                    "query": query_text,
                    "boost": settings.HYBRID_BM25_WEIGHT,
                }
            }
        },
        "size": fetch_k,
    }
    resp = await es_client.search(index=_child_index(kb_name), body=body)
    return [hit["_source"] for hit in resp["hits"]["hits"]]


async def fetch_parent_docs(kb_name: str, parent_ids: list[str]) -> list[dict]:
    """根据父文档 ID 列表批量获取父文档内容（自动去重）"""
    unique_ids = list(dict.fromkeys(parent_ids))  # 保序去重
    if not unique_ids:
        return []
    resp = await es_client.mget(
        index=_parent_index(kb_name),
        body={"ids": unique_ids},
    )
    return [
        doc["_source"]
        for doc in resp["docs"]
        if doc.get("found")
    ]


async def keyword_exact_search(query_text: str, top_k: int) -> list[dict]:
    """
    在知识库C 中按 content 字段精确匹配
    知识库C 的 content 是 keyword 类型，支持 term 精确查询
    前缀匹配以支持 'prefix 主营业务关键词：{keyword}' 的模糊查找
    """
    body = {
        "query": {
            "term": {"content": {"value": query_text}}
        },
        "size": top_k,
    }
    resp = await es_client.search(index=settings.INDEX_KB_C, body=body)
    return [hit["_source"] for hit in resp["hits"]["hits"]]


async def keyword_prefix_search(keyword: str, top_k: int) -> list[dict]:
    """
    用 match_phrase_prefix 检索知识库C
    召回所有以 '主营业务关键词：{keyword}' 开头的记录，再在代码层做精确匹配
    """
    query_str = f"主营业务关键词：{keyword}"
    body = {
        "query": {
            "match": {"content": query_str}
        },
        "size": top_k,
    }
    resp = await es_client.search(index=settings.INDEX_KB_C, body=body)
    return [hit["_source"] for hit in resp["hits"]["hits"]]
