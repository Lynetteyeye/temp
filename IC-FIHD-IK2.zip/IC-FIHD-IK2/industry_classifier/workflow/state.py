"""
LangGraph 工作流状态定义
使用 TypedDict 描述整个工作流的共享状态，节点通过返回字典来更新部分状态
"""
from typing import Optional
from typing_extensions import TypedDict


class WorkflowState(TypedDict, total=False):
    """
    工作流全局状态
    total=False 表示所有字段均为可选，节点只需返回自己修改的字段
    """

    # ==================== 工作流输入（由 START 节点注入）====================
    company_name: str          # 公司名称
    business_name: str         # 要识别行业的业务名称
    all_business_name: str     # 公司所有业务名称（用于辅助分析"其他"类模糊业务）
    company_info: str          # 公司整体业务信息
    business_info: str         # 要识别行业的业务详细信息
    dm_industry_name: str      # DM 预判行业名（可选参考）
    dm_industry_info: str      # DM 预判行业信息（可选参考）

    # ==================== 关键词匹配路径（快速路径）====================
    # 代码节点：拼接关键词匹配参数
    keyword_query: str         # "主营业务关键词：{business_name}"

    # 知识库C 检索原始结果
    keyword_search_results: list[dict]

    # 代码节点：从检索结果中确认精确匹配的行业
    keyword_match_name: Optional[str]
    keyword_match_code: Optional[str]
    keyword_matched: bool      # True = 命中精确关键词，走快速路径

    # ==================== LLM 判断路径（慢路径）====================
    # LLM 2：提取业务关键词（含 <think> 标签的原始输出）
    llm_raw_keywords: str

    # 代码节点：剔除 </think> 标签后的纯净查询文本
    kb_query: str

    # 知识库A 检索结果（行业分类标准）
    kb_a_results: list[dict]

    # 知识库B 检索结果（相似公司历史结果）
    kb_b_results: list[dict]

    # 代码节点：B 中有 A 中没有的行业代码列表，如 ["行业代码：TZ700101", ...]
    missing_industry_codes: list[str]

    # 迭代补充检索：对每个缺失行业代码在 KB-A 中单独检索，聚合后的结果
    kb_a_supplement_results: list[dict]

    # 代码节点：将 KB-A、KB-A补充、KB-B 拼接为统一上下文字符串
    merged_context: str

    # ==================== 最终输出 ====================
    # 工作流最终返回的原始文本（与 Dify 输出格式兼容，含 <think> 和 ```json 块）
    final_output: str

    # 解析后的结构化结果
    result_json: dict

    # 执行路径标记："keyword" 或 "llm"
    path_type: str
